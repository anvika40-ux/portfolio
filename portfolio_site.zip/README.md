# Anuradha Chaurasiya - Portfolio Website

This is a simple portfolio website showcasing skills, projects, and contact details.

## Files
- index.html
- portfolio-style.css

## Hosting
You can host this on GitHub Pages by enabling Pages from the repository settings.
